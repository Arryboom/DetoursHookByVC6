#define DETOURS_IA64_OFFLINE_LIBRARY
#include "disasm.cpp"
